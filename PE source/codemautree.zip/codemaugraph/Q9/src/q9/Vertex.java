/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q9;

/**
 *
 * @author Nguyen Van Quoc Bao - SE161837
 */
public class Vertex {

    int value;

    public Vertex() {
    }

    public Vertex(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
